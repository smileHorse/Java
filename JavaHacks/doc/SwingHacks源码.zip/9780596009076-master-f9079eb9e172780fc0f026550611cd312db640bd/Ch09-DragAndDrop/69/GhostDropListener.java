public interface GhostDropListener {
	public void ghostDropped(GhostDropEvent e);
}
